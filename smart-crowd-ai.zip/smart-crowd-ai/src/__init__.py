# Smart Crowd AI package
